#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

/*
 * get_run_and_length
 *
 * Read and return the next run and length from _file_ (in output
 * parameters _length_ and _run_) if the file contains properly
 * formatted input. Return true/false depending upon whether
 * the get was successful.
 *
 * input: the _file_ from which to read.
 * output: the _length_ of the run specified in the _file_;
 *         the _run_ character of the run specified in the _file_;
 *         true/false depending on whether the file was properly
 *         formatted and a read could happen.
 */
bool get_run_and_length(std::ifstream &file, int &length, char &run, bool &needed_dash) {
  // Try to read a integer and a character.
  bool success = !!(file >> length) && !!(file >> run);

  // Now, if there was a successful read of an integer
  // and a character, that character may indicate that
  // we need to do a further read because we need the
  // character after a -.
  if (success && run == '-') {
    needed_dash = true;
    return !!(file >> run);
  }
  return success;
}

/*
 * data_available
 *
 * Determine whether there is data available to read from _file_.
 *
 * input: The file to check for available data.
 * output: true if _file_ has data to read; false, otherwise.
 */
bool data_available(std::ifstream &file) {
  return (EOF != file.peek() && 0 == std::iscntrl(file.peek()));
}

/*
 * representative_size
 *
 * Determine the number of characters required to represent
 * an integer _number_.
 *
 * input: The number for which to determine the number of
 * characters required by a "string" representation.
 * output:  The number of characters required by a "string"
 * representation of _number_.
 */
int representative_size(int number) {
  int i = 1;
  // For as long as we can divide by 10, we know
  // that it takes 1 character to represent. So,
  // divide by 10 (and don't worry about the remainder)
  // until we are at 0! Every time that we loop,
  // increment the number of required characters in the
  // representations by 1.
  for (; (number /= 10) != 0; i++) {
  }
  return i;
}

/*
 * format_compression_ratio
 *
 * This function will properly format _compression_ratio_ according
 * to the specifications set forth in the lab document.
 *
 * input: a double, _compression_ratio_, that is the compression ratio
 *        to format.
 * output: a std::string that contains _compression_ratio_ properly
 *         formatted according to the specifications set forth in
 *         the lab document.
 */
std::string format_compression_ratio(double compression_ratio) {
  std::stringstream formatted_ss{};
  formatted_ss << std::fixed << std::setprecision(2) << compression_ratio;
  return formatted_ss.str();
}

int main() {
  std::string compressed_file_name{"input.rle"};
  std::ifstream compressed_file{compressed_file_name};
  int compressed_length{0};
  int uncompressed_length{0};
  bool format_error{false};
  double compression_ratio{0.0};
  std::string decompressed{""};

  if (!compressed_file.is_open()) {
    std::cout << "Could not open the file containing the compressed data!\n";
    return EXIT_FAILURE;
  }
  while (data_available(compressed_file)) {
    char run{' '};
    int length{-1};
    bool needed_dash{false};
    if (get_run_and_length(compressed_file, length, run, needed_dash)) {
      // Adding 1 to representative_size result to account for _run_'s
      // presence in the file.
      compressed_length += representative_size(length) + 1;
      // If we needed a dash then there is one more character to account
      // for in the length of the compressed file.
      if (needed_dash) {
        compressed_length += 1;
      }
      // Now, let's append _run_ _length_ times to _decompressed_.
      for (int i = 0; i < length; i++) {
        uncompressed_length++;
        decompressed += run;
      }
    } else {
      format_error = true;
      break;
    }
  }

  if (format_error) {
    std::cout << "Compressed data format error!\n";
    compressed_file.close();
    return EXIT_FAILURE;
  }

  std::cout << decompressed << "\n";

  // We want to be super defensive. Either one could be zero
  // and that would cause some very odd results.
  if (compressed_length > 0 && uncompressed_length > 0) {
    compression_ratio =
        static_cast<double>(uncompressed_length) / compressed_length;
  }
  std::cout << format_compression_ratio(compression_ratio) << "\n";

  compressed_file.close();

  return EXIT_SUCCESS;
}
